import java.io.*; 
import java.rmi.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;
import java.util.stream.Collector;
import javax.swing.JFileChooser;
import java.lang.Math;
import java.lang.Object;
import java.nio.*;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.nio.file.*;



public class FileClient{

   static String uniqueID = UUID.randomUUID().toString();
   private String fileName;

   // parseFile Method
   public void thesaurus(String fileName, String searchStr) throws FileNotFoundException {
      
      boolean wordFound = false;
      int temp = 0;

      Scanner scan = new Scanner(new File(fileName));
      // console.log;

      while (scan.hasNextLine()) {
         // console.log;
         
         String line = scan.nextLine().toLowerCase().toString();
         boolean inFile = line.equalsIgnoreCase(searchStr);
         // scan.close();
         // else
         // {
         // System.out.println("Search String not found");
         // }
         if (line.contains(searchStr)) {
            // System.out.println("Testing print line");
            System.out.println(line);
            wordFound = true;
            temp += 1;
         }
         else if(!(line.contains(searchStr)))
         //else
         {
            wordFound = false;
            //System.out.println("Word is not found in the current thesaurus");
            //System.exit(0);
            temp -=1;
         }

      }
      //System.out.println("exit of loop");
      //System.out.println(temp);
      //if (wordFound = true)
      if (wordFound = false)
      //if (temp < 1);
      {
         System.out.println("Word is not found in the current thesaurus");
      }
   }

   // Searching transcation
   public void transactionFile(String fileName, String searchStr) throws IOException {
      File tempFile = new File(fileName);
      // boolean exists = tempFile.exists();
      // System.out.println(exists);
      File file = new File(fileName);
      Scanner sc = new Scanner(file);

      int count = 0;

      // console.log;
      System.out.println("In file: " + fileName);

      Scanner scan = new Scanner(new File(fileName));

      // console.log;
      while (scan.hasNextLine()) {
         // console.log;
         // System.out.println("TestING1");
         String line = scan.nextLine().toLowerCase().toString();
         // System.out.println(line);
         // boolean inFile = line.equalsIgnoreCase(searchStr);
         // scan.close();

         if (line.contains(searchStr)) {
            // console.log;
            System.out.println(line);
            count++;
            System.out.println("Transaction Number: " + count);
         }
      }
   }

   // @@@MAIN@@@
   public static void main(String argv[]) throws FileNotFoundException {

      FileClient fileSearch = new FileClient();
      FileClient fileUp = new FileClient();
      String command = argv[2];
      // while(!(command.equalsIgnoreCase("close")))
      // {

      if(argv.length != 2&&argv.length!=3&&argv.length!=4&&argv.length>6) 
      {
        System.out.println("List of Available Commands: ");
        System.out.println("Usage: java FileClient fileName machineName");//
        System.out.println("OR \nUsage: java FileClient fileName machineName GPA");//X
        System.out.println("OR \nUsage: java FileClient fileName machineName GPAadd");//*X
        System.out.println("OR \nUsage: java FileClient fileName machineName Thesaurus SearchWord");//X
        System.out.println("OR \nUsage: java FileClient fileName machineName thesaurusAdd WordAdded Synonym");//X
        System.out.println("OR \nUsage: java FileClient fileName machineName thesaurusAddUp WordAdded SynonmAdded"); 
        System.out.println("OR \nUsage: java FileClient fileName machineName Message Name StudentID Class");//X 
        System.out.println("OR \nUsage: java FileClient fileName machineName Tlookup SearchString");//X
        System.exit(0);
      }
      

      try {
         // Looking for file to download based on input
         String name = "//" + argv[1] + "/FileServer";
         FileInterface fi = (FileInterface) Naming.lookup(name);
         byte[] filedata = fi.downloadFile(argv[0]);
         File file = new File(argv[0]);
         BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file.getName()));
         output.write(filedata, 0, filedata.length);

         // clear the buffer before doing anything
         // had runtime error here, keep it here so that file will actually read & shoW!!
         output.flush();
         output.close();

         // After downloading
         System.out.println("File: " + file.getName() + " has been successfully downloaded!");

         // This command will run if conditions are satisifed, 4 arugments and command
         // "Tlookup" is called
         // input parameters are Filename IPAddress Tlookup TransactionName
         // Will output the transactions that occured with that item
         // Shows how many transactions occured
         // Asks user for input
         if (argv.length == 4 && command.equalsIgnoreCase("Tlookup")) {
            System.out.println("Searching for String: " + argv[3]);
            // search within file
            fileSearch.transactionFile(file.getName(), argv[3]);
         }
         // If command = thesaurus
         // input parameters are Filename IPAddress Thesaurus SearchWord
         // Will ouutput the synonyms for the word you searched for
         // Will consider input from user
         else if (argv.length == 4 && command.equalsIgnoreCase("Thesaurus")) {
            System.out.println("Searching for String: " + argv[3]);
            // Show synonym of word
            fileSearch.thesaurus(file.getName(), argv[3]);
         }

         // IF GPAcalc command is called
         // input parameters are Filename IPAddress GPACalc
         // Will output a quiz paper
         // Will consider input from user
         else if (argv.length == 3 && command.equalsIgnoreCase("GPA")) {
            System.out.println("Calculating GPA from file: " + file.getName());
            fileSearch.GPACalc(file.getName());
            // System.out.println("Searching for String: " + argv[3]);
            // Show
            // fileSearch._(file.getName());
         }

         else if (command.equalsIgnoreCase("GPAadd")) {
            System.out.println("Calculating GPA from file: " + file.getName());
            
            // System.out.println("Searching for String: " + argv[3]);
            // Show 
            int maxSize = argv.length;
            try {
               FileWriter fw = new FileWriter(file.getName(), true);
               for (int i =0; i<maxSize; i ++)
               {
                  fw.write("\n"+argv[i]);
               }
               //fw.write("\n");
               //fw.write(argv[3]);
               //fw.write(" ");
               //fw.write(argv[4]);
               fw.close();

            } catch (IOException ioe) {
               // exception handling
            }
            fileSearch.GPACalc(file.getName());
            
         }

         else if (argv.length == 5 && command.equalsIgnoreCase("ThesaurusAdd")) {
            System.out.println(
                  "Adding Word and Synonym " + "'(" + argv[3] + " " + argv[4] + ")'" + " to " + file.getName());
            // System.out.println("Searching for String: " + argv[3]);
            fileSearch.thesaurusAdd(file.getName());
            try {
               FileWriter fw = new FileWriter(file.getName(), true);
               fw.write("\n");
               // fw.append("text 2222");
               fw.write(argv[3]);
               fw.write(" ");
               fw.write(argv[4]);
               fw.close();

            } catch (IOException ioe) {
               // exception handling
            }
         }

         else if (argv.length > 4 && command.equalsIgnoreCase("Message")) {

            // show all of text line by line in here
            // System.out.println("Message to be sent: " + line);
            // add signature in here which will be IPAddress

            // System.out.println("Searching for String: " + argv[3]);
            fileSearch.message(file.getName());
            try {
               // argv3 = name
               // argv4 = Student ID
               // argv5 = Class
               // User ID
               FileWriter fw = new FileWriter(file.getName(), true);
               fw.append("\n_______________________________________________________");
               fw.append("\nSender Info: " + argv[3] + " ");
               fw.append("\nStudent Number: " + argv[4]);
               fw.append("\nClass: " + argv[5]);
               fw.append("\nFrom UserID: ");
               fw.append(uniqueID);
               fw.close();

            } catch (IOException ioe) {
               // exception handling
            }

         }

         // @@@@@@@@@@
         // catch block if couldn't launch properly
      } catch (Exception e) {
         System.err.println("File Download Error: " + e.getMessage());
         e.printStackTrace();
      }
   }

   public void message(String fileName) throws FileNotFoundException {
      ArrayList <String> inputMessage = new ArrayList<String>();
      Scanner scan = new Scanner(new File(fileName));

      while (scan.hasNextLine())
      {
         String line = scan.nextLine().toLowerCase().toString();
         inputMessage.add(line);
      }


      // console.log;
      File tempFile = new File(fileName);
      boolean exists = tempFile.exists();
      JFileChooser chooser = new JFileChooser();
      int returnValue = chooser.showOpenDialog(null);

      try {

         String fpath = tempFile.getAbsolutePath();

         if (returnValue == JFileChooser.APPROVE_OPTION) {
            fileName = chooser.getSelectedFile().toString();
         } else if (fileName != null) {
            fpath = tempFile.getAbsolutePath();
         }

         if (exists == true) 
         {
            System.out.println("Message has been found and been sent");
         } 
         else 
         {
            System.out.println("Message file cannot be found");
         }
      } 
      catch (Exception ioe) 
      {
         // System.out.print(e.getMessage);
      }


   }

   public void thesaurusAdd(String fileName) throws FileNotFoundException {
      Scanner scan = new Scanner(new File(fileName));
      // console.log;
      File tempFile = new File(fileName);
      boolean exists = tempFile.exists();
      // JFileChooser chooser = new JFileChooser();
      // int returnValue = chooser.showOpenDialog( null );

      try {

         /*
          * String fpath = tempFile.getAbsolutePath();
          * 
          * if (returnValue == JFileChooser.APPROVE_OPTION) { fileName =
          * chooser.getSelectedFile().toString(); } else if(fileName !=null) { fpath =
          * tempFile.getAbsolutePath(); }
          */

         if (exists == true) {
            System.out.println("Word with Synonym has been added to thesaurus");
         } else {
            System.out.println("Thesaurus cannot be found");
         }
      } catch (Exception ioe) {
         // System.out.print(e.getMessage);
      }

      // while (scan.hasNextLine()) {
      // console.log;
      // String line = scan.nextLine().toLowerCase().toString();
      // console.log;
      // boolean inFile = line.equalsIgnoreCase(searchStr);
      // scan.close();
      // else
      // {
      // System.out.println("Search String not found");
      // }
      // if (line.contains(searchStr)) {
      // // System.out.println("Testing print line");
      // System.out.println(line);
      // }

      // }
   }

   public void GPACalc(String fileName) throws FileNotFoundException {
      // double total, avg = 0;
      double avg = 0;
      double total = 0;
      int count = 0;
      Scanner scan = new Scanner(new File(fileName));
      // console.log;

      while (scan.hasNextLine()) {
         String line = scan.nextLine();
         // console.log;

         // double value = Double.parseDouble(line);
         double value = (scan.nextDouble());

         total += value;
         count++;
         String letterGrade;
         // System.out.println(total);
         // console.log;
         // scan.close();

         // read inputs until no more next line!!
         if (!(scan.hasNextLine())) {
            // console.log
            avg = total / count;
            // System.out.println(total);
            System.out.println("Number of courses: " + count);
            DecimalFormat df = new DecimalFormat("#.##");
            // System.out.println(avg);
            System.out.println("Cumulative GPA: " + df.format(avg));

            if (avg > 4.0)
            {
               letterGrade = "A+";
               System.out.println(letterGrade);
            }
            else 
               if (4 <= avg && avg < 4.3)
               {
                  letterGrade = "A";
                  System.out.println(letterGrade);
               }
            else 
               if (3.7 <= avg && avg < 4)
               {
                  letterGrade = "A-";
                  System.out.println(letterGrade);
               }
               else 
               if (3.3 <= avg && avg < 3.7)
               {
                  letterGrade = "B+";
                  System.out.println(letterGrade);
               }
               else 
               if (3 <= avg && avg < 3.3)
               {
                  letterGrade = "B";
                  System.out.println(letterGrade);
               }
               else 
               if (2.7 <= avg && avg < 3)
               {
                  letterGrade = "B-";
                  System.out.println(letterGrade);
               }
               else 
               if (2.3 <= avg && avg < 2.7)
               {
                  letterGrade = "C+";
                  System.out.println(letterGrade);
               }
               else 
               if (2 <= avg && avg < 2.3)
               {
                  letterGrade = "C";
                  System.out.println(letterGrade);
               }
               else 
               if (1.7 <= avg && avg < 2)
               {
                  letterGrade = "C-";
                  System.out.println(letterGrade);
               }
               else 
               if (1 <= avg && avg < 1.7)
               {
                  letterGrade = "D";
                  System.out.println(letterGrade);
               }
               else 
               if (0<= avg && avg < 1)
               {
                  letterGrade = "F";
                  System.out.println(letterGrade);
               }
               else
               {
                  letterGrade ="INVALID";
                  System.out.println(letterGrade);
               }
         }
      }
   }
   
   //ADDING TO GPAadd
   public void GPAadd(String fileName) throws FileNotFoundException {
      // double total, avg = 0;
      double avg = 0;
      double total = 0;
      int count = 0;
      Scanner scan = new Scanner(new File(fileName));
      // console.log;
      String letterGrade;

      while (scan.hasNextLine()) {
         String line = scan.nextLine();
         // console.log;

         // double value = Double.parseDouble(line);
         double value = (scan.nextDouble());

         total += value;
         count++;
         // System.out.println(total);
         // console.log;
         // scan.close();

         // read inputs until no more next line!!
         if (!(scan.hasNextLine())) {
            // console.log
            avg = total / count;
            // System.out.println(total);
            System.out.println("Number of courses: " + count);
            DecimalFormat df = new DecimalFormat("#.##");
            // System.out.println(avg);
            System.out.println("Cumulative GPA: " + df.format(avg));

            if (avg > 4.0)
            {
               letterGrade = "A+";
               System.out.println(letterGrade);
            }
            else 
               if (4 <= avg && avg < 4.3)
               {
                  letterGrade = "A";
                  System.out.println(letterGrade);
               }
            else 
               if (3.7 <= avg && avg < 4)
               {
                  letterGrade = "A-";
                  System.out.println(letterGrade);
               }
               else 
               if (3.3 <= avg && avg < 3.7)
               {
                  letterGrade = "B+";
                  System.out.println(letterGrade);
               }
               else 
               if (3 <= avg && avg < 3.3)
               {
                  letterGrade = "B";
                  System.out.println(letterGrade);
               }
               else 
               if (2.7 <= avg && avg < 3)
               {
                  letterGrade = "B-";
                  System.out.println(letterGrade);
               }
               else 
               if (2.3 <= avg && avg < 2.7)
               {
                  letterGrade = "C+";
                  System.out.println(letterGrade);
               }
               else 
               if (2 <= avg && avg < 2.3)
               {
                  letterGrade = "C";
                  System.out.println(letterGrade);
               }
               else 
               if (1.7 <= avg && avg < 2)
               {
                  letterGrade = "C-";
                  System.out.println(letterGrade);
               }
               else 
               if (1 <= avg && avg < 1.7)
               {
                  letterGrade = "D";
                  System.out.println(letterGrade);
               }
               else 
               if (0<= avg && avg < 1)
               {
                  letterGrade = "F";
                  System.out.println(letterGrade);
               }
               else
               {
                  letterGrade ="INVALID";
                  System.out.println(letterGrade);
               }
         }
      }
   }

   public void uploadFile(String fileName) throws FileNotFoundException {
	Scanner scan = new Scanner(new File(fileName));
      // console.log;
      File tempFile = new File(fileName);
      boolean exists = tempFile.exists();
      String tempPlace0, tempPlace1 = "0";
      tempPlace1 = "192.168.56.1";

      try 
      {
      String name = "//" + tempPlace1 + "/FileServer";
        FileInterface fi = (FileInterface) Naming.lookup(name);
        File file = new File(fileName);
        byte buffer[] = new byte[(int)file.length()];
        BufferedInputStream input = new BufferedInputStream(new FileInputStream(fileName));
        input.read(buffer,0,buffer.length);
        input.close();
        String val = fi.uploadFile(fileName, buffer);
        System.out.println(val);
        //System.out.println("File Saved Successfully");

         if (exists==true)
         {
            //System.out.println("Word with Synonym has been added to thesaurus");
         }
         else {
            //System.out.println("thesaurus cannot be found");
         }
      } 
      catch(Exception e) 
      {
         System.err.println("FileServer exception: "+ e.getMessage());
         e.printStackTrace();
      }
   }
}